#ifndef IO_H
#define IO_H

#include <string>
#include <vector>
using namespace std;
vector<string> splitLine(string line);

#endif